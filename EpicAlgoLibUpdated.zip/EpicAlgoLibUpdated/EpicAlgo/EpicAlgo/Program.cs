﻿using EpicAlgo.HashTables;
using EpicAlgo.Timers.Timer;
using EpicAlgo.Trees.BinaryTree;
using EpicAlgo.Trees.Interfaces;
using System;
using System.Collections.Generic;


namespace EpicAlgo
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
